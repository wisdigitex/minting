function addItem(button) {
    var quantityElement = button.parentElement.querySelector('.quantity');
    var quantity = parseInt(quantityElement.textContent);
    quantity++;
    quantityElement.textContent = quantity;
}

function reduceItem(button) {
    var quantityElement = button.parentElement.querySelector('.quantity');
    var quantity = parseInt(quantityElement.textContent);
    if (quantity > 1) {
        quantity--;
        quantityElement.textContent = quantity;
    }
}

function mintItem() {
    // Logic for minting item
}
document.getElementById('clear-cart').addEventListener('click', function() {
    // Logic to clear the cart
    // For example:
    // document.querySelector('.cart-items').innerHTML = '';
});

