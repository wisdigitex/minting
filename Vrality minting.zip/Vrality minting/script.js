// Function to toggle the visibility of the cart page
function toggleCart() {
    var cartPage = document.getElementById("cartPage");
    cartPage.classList.toggle("hidden");
    cartPage.classList.toggle("visible");
}
